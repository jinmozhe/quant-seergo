# app/db/repositories/__init__.py
"""Repositories module (data access layer)"""
