# app/db/__init__.py
"""Database module"""
