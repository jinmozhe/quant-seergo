# app/api/__init__.py
"""API module (global dependencies and utilities)"""
