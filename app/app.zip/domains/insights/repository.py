"""
File: app/domains/insights/repository.py
Description: 洞察领域仓储层

包含：
1. InsightsReportRepository: 报告列表查询 & 最新报告查询
2. InsightsQARepository: 获取上下文 & 问答记录管理

Author: jinmozhe
Created: 2026-02-08
Updated: 2026-02-09 (Fix Pylance return type issue via load_only)
"""

from uuid import UUID

from pydantic import BaseModel
from sqlalchemy import asc, desc, select, update
from sqlalchemy.orm import load_only  # ✅ 新增导入

from app.db.models.insights_report import InsightsReport
from app.db.models.insights_report_qa import InsightsReportQA
from app.db.repositories.base import BaseRepository


class InsightsReportRepository(BaseRepository[InsightsReport, BaseModel, BaseModel]):
    """
    洞察报告仓储
    """

    async def get_flat_reports(
        self, user_id: str, marketplace_id: str, limit: int = 100
    ) -> list[InsightsReport]:
        """
        获取用户最近的报告列表 (元数据)。
        使用 load_only 排除 kpi, insights, ai 大字段以提升性能，
        同时返回标准的 ORM Model 对象以满足类型检查。
        """
        stmt = (
            select(InsightsReport)
            .options(
                # ✅ 仅加载指定字段，其他字段延迟加载
                load_only(
                    InsightsReport.id,
                    InsightsReport.ad_type,
                    InsightsReport.period_start,
                    InsightsReport.period_end,
                    InsightsReport.report_type,
                    InsightsReport.report_source,
                    InsightsReport.pdf_path,
                )
            )
            .where(
                InsightsReport.user_id == user_id,
                InsightsReport.marketplace_id == marketplace_id,
            )
            .order_by(desc(InsightsReport.period_start))
            .limit(limit)
        )

        result = await self.session.execute(stmt)
        # ✅ 使用 scalars() 获取模型实例，而不是 Row 元组
        return list(result.scalars().all())

    async def get_latest_report(
        self,
        user_id: str,
        marketplace_id: str,
        ad_type: str,
        report_type: str,
        report_source: str,
    ) -> InsightsReport | None:
        """
        根据维度条件获取最新一份报告 (按 period_start 倒序)
        """
        stmt = (
            select(InsightsReport)
            .where(
                InsightsReport.user_id == user_id,
                InsightsReport.marketplace_id == marketplace_id,
                InsightsReport.ad_type == ad_type,
                InsightsReport.report_type == report_type,
                InsightsReport.report_source == report_source,
            )
            .order_by(desc(InsightsReport.period_start))  # 按日期倒序
            .limit(1)
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()


class InsightsQARepository(BaseRepository[InsightsReportQA, BaseModel, BaseModel]):
    """
    洞察问答仓储
    """

    async def get_report_context(self, report_id: UUID) -> dict | None:
        """
        获取 RAG 所需的上下文数据。
        Insights 报告需要聚合 kpi, insights, ai 三个字段。
        """
        stmt = select(
            InsightsReport.kpi, InsightsReport.insights, InsightsReport.ai
        ).where(InsightsReport.id == report_id)

        result = await self.session.execute(stmt)
        row = result.one_or_none()

        if not row:
            return None

        # 将三个 JSON 字段合并为一个上下文对象
        return {"kpi": row.kpi, "insights": row.insights, "ai": row.ai}

    async def get_qa_by_id(self, qa_id: UUID) -> InsightsReportQA | None:
        """
        获取单条问答记录。
        """
        stmt = select(InsightsReportQA).where(InsightsReportQA.id == qa_id)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def create_qa_record(
        self, user_id: str, marketplace_id: str, report_id: UUID, question: str
    ) -> InsightsReportQA:
        """
        创建一条初始状态(PENDING)的问答记录。
        """
        qa_record = InsightsReportQA(
            user_id=user_id,
            marketplace_id=marketplace_id,
            report_id=report_id,
            question=question,
            status="PENDING",
            answer=None,
        )
        self.session.add(qa_record)
        return qa_record

    async def update_status(self, qa_id: UUID, status: str) -> None:
        """
        仅更新状态。
        """
        stmt = (
            update(InsightsReportQA)
            .where(InsightsReportQA.id == qa_id)
            .values(status=status)
        )
        await self.session.execute(stmt)

    async def update_answer(self, qa_id: UUID, answer: str, status: str) -> None:
        """
        更新最终回答内容和状态。
        """
        stmt = (
            update(InsightsReportQA)
            .where(InsightsReportQA.id == qa_id)
            .values(answer=answer, status=status)
        )
        await self.session.execute(stmt)

    async def get_chat_history(
        self, user_id: str, marketplace_id: str, report_id: UUID
    ) -> list[InsightsReportQA]:
        """
        获取指定报告的对话历史，按时间正序排列。
        """
        stmt = (
            select(InsightsReportQA)
            .where(
                InsightsReportQA.report_id == report_id,
                InsightsReportQA.user_id == user_id,
                InsightsReportQA.marketplace_id == marketplace_id,
            )
            .order_by(asc(InsightsReportQA.created_at))
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())
